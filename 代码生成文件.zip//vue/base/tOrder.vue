<template>
  <div class="c-pd-20">
    <c-table-page
        ref="tablePage"
        apiStr="/base/tOrder/page"
        :query="queryParam"
        :bordered="true"
        :columnsLen="8"
        :shortDetail="true"
        :actionRow="proxy.$tools.getLocalCache('actionRow') === 'true'"
        :actionPostionRight="proxy.$tools.getLocalCache('actionPostionRight') === 'true'"
        :columns="tableColumns"
    >
      <template v-slot:actionBar>
        <a-button type="primary" @click="optionDropdownClick({ type: 'add' })">新增</a-button>
      </template>
      <template v-slot:searchBar>
        <a-input v-model:value="queryParam.name" @keyup.enter.stop="doSearch" placeholder="请输入订单名称"/>
        <a-input v-model:value="queryParam.status" @keyup.enter.stop="doSearch" placeholder="请输入订单状态"/>
      </template>
      <template #actions="{ record }">
        <a-button type="link" @click="optionDropdownClick({ type: 'edit' , record: record })">编辑</a-button>
        <a-button type="link" @click="optionDropdownClick({ type: 'detail' , record: record })">详情</a-button>
        <c-button type="link" btnClass="error" isPop popTitle="确定要删除该数据吗？" @confirm="optionDropdownClick({ type: 'delete' , record: record })">删除</c-button>
      </template>
    </c-table-page>

  <!-- 新增 -->
  <c-simple-dialog
    ref="dialogAddRef"
    mode="outer"
    title="新增"
    subUrl="/base/tOrder/saveTOrder"
    width="66%"
    @ok="doSearch"
    @check="doAddCheck"
  >
    <a-form :wrapper-col="horizontal.wrapperCol" :label-col="horizontal.labelCol" ref="formAddRef" :model="dataAddForm" :rules="formAddRules">
      <a-form-item label="订单名称" require  name="name">
        <a-input v-model:value="dataAddForm.name" placeholder="请输入订单名称"/>
      </a-form-item>
      <a-form-item label="购买产品" name="powerSite">
        <a-input v-model:value="dataAddForm.powerSite" placeholder="请输入购买产品"/>
      </a-form-item>
      <a-form-item label="一次报价" require  name="firstPrice">
        <a-input v-model:value="dataAddForm.firstPrice" placeholder="请输入一次报价"/>
      </a-form-item>
      <a-form-item label="一次报价时间" require  name="firstPriceTime">
        <a-input v-model:value="dataAddForm.firstPriceTime" placeholder="请输入一次报价时间"/>
      </a-form-item>
      <a-form-item label="一次报价用户" require  name="firstPriceUser">
        <a-input v-model:value="dataAddForm.firstPriceUser" placeholder="请输入一次报价用户"/>
      </a-form-item>
      <a-form-item label="一次报价确认" name="firstPriceConfirm">
        <a-input v-model:value="dataAddForm.firstPriceConfirm" placeholder="请输入一次报价确认"/>
      </a-form-item>
      <a-form-item label="一次报价确认时间" name="firstPriceConfirmTime">
        <a-input v-model:value="dataAddForm.firstPriceConfirmTime" placeholder="请输入一次报价确认时间"/>
      </a-form-item>
      <a-form-item label="一次报价确认用户" name="firstPriceConfirmUser">
        <a-input v-model:value="dataAddForm.firstPriceConfirmUser" placeholder="请输入一次报价确认用户"/>
      </a-form-item>
      <a-form-item label="二次报价" require  name="secondPrice">
        <a-input v-model:value="dataAddForm.secondPrice" placeholder="请输入二次报价"/>
      </a-form-item>
      <a-form-item label="二次报价时间" require  name="secondPriceTime">
        <a-input v-model:value="dataAddForm.secondPriceTime" placeholder="请输入二次报价时间"/>
      </a-form-item>
      <a-form-item label="二次报价用户" require  name="secondPriceUser">
        <a-input v-model:value="dataAddForm.secondPriceUser" placeholder="请输入二次报价用户"/>
      </a-form-item>
      <a-form-item label="二次报价确认" name="secondPriceConfirm">
        <a-input v-model:value="dataAddForm.secondPriceConfirm" placeholder="请输入二次报价确认"/>
      </a-form-item>
      <a-form-item label="二次报价确认时间" name="secondPriceConfirmTime">
        <a-input v-model:value="dataAddForm.secondPriceConfirmTime" placeholder="请输入二次报价确认时间"/>
      </a-form-item>
      <a-form-item label="" name="secondPriceConfirmUser">
        <a-input v-model:value="dataAddForm.secondPriceConfirmUser" placeholder="请输入"/>
      </a-form-item>
      <a-form-item label="订单状态" require  name="status">
        <a-input v-model:value="dataAddForm.status" placeholder="请输入订单状态"/>
      </a-form-item>
      <a-form-item label="订金" require  name="deposit">
        <a-input v-model:value="dataAddForm.deposit" placeholder="请输入订金"/>
      </a-form-item>
      <a-form-item label="订金支付时间" require  name="depositTime">
        <a-input v-model:value="dataAddForm.depositTime" placeholder="请输入订金支付时间"/>
      </a-form-item>
      <a-form-item label="支付用户" require  name="depositUser">
        <a-input v-model:value="dataAddForm.depositUser" placeholder="请输入支付用户"/>
      </a-form-item>
      <a-form-item label="尾款" require  name="retainage">
        <a-input v-model:value="dataAddForm.retainage" placeholder="请输入尾款"/>
      </a-form-item>
      <a-form-item label="支付尾款时间" require  name="retainageTime">
        <a-input v-model:value="dataAddForm.retainageTime" placeholder="请输入支付尾款时间"/>
      </a-form-item>
      <a-form-item label="支付尾款用户" require  name="retainageUser">
        <a-input v-model:value="dataAddForm.retainageUser" placeholder="请输入支付尾款用户"/>
      </a-form-item>
      <a-form-item label="合同" require  name="contract">
        <a-input v-model:value="dataAddForm.contract" placeholder="请输入合同"/>
      </a-form-item>
      <a-form-item label="合同上传时间" require  name="contractTime">
        <a-input v-model:value="dataAddForm.contractTime" placeholder="请输入合同上传时间"/>
      </a-form-item>
      <a-form-item label="合同上传用户" require  name="contractUser">
        <a-input v-model:value="dataAddForm.contractUser" placeholder="请输入合同上传用户"/>
      </a-form-item>
      <a-form-item label="创建人" require  name="createUser">
        <a-input v-model:value="dataAddForm.createUser" placeholder="请输入创建人"/>
      </a-form-item>
      <a-form-item label="创建时间" require  name="createTime">
        <a-input v-model:value="dataAddForm.createTime" placeholder="请输入创建时间"/>
      </a-form-item>
    </a-form>
  </c-simple-dialog>

  <!-- 编辑 -->
  <c-simple-dialog
    ref="dialogEditRef"
    mode="outer"
    title="编辑"
    subUrl="/base/tOrder/saveTOrder"
    width="66%"
    @ok="doSearch"
    @check="doEditCheck"
  >
    <a-form :wrapper-col="horizontal.wrapperCol" :label-col="horizontal.labelCol" ref="formEditRef" :model="dataEditForm" :rules="formEditRules">
      <a-form-item label="订单名称" require  name="name">
        <a-input v-model:value="dataEditForm.name" placeholder="请输入订单名称"/>
      </a-form-item>
      <a-form-item label="购买产品" name="powerSite">
        <a-input v-model:value="dataEditForm.powerSite" placeholder="请输入购买产品"/>
      </a-form-item>
      <a-form-item label="一次报价" require  name="firstPrice">
        <a-input v-model:value="dataEditForm.firstPrice" placeholder="请输入一次报价"/>
      </a-form-item>
      <a-form-item label="一次报价时间" require  name="firstPriceTime">
        <a-input v-model:value="dataEditForm.firstPriceTime" placeholder="请输入一次报价时间"/>
      </a-form-item>
      <a-form-item label="一次报价用户" require  name="firstPriceUser">
        <a-input v-model:value="dataEditForm.firstPriceUser" placeholder="请输入一次报价用户"/>
      </a-form-item>
      <a-form-item label="一次报价确认" name="firstPriceConfirm">
        <a-input v-model:value="dataEditForm.firstPriceConfirm" placeholder="请输入一次报价确认"/>
      </a-form-item>
      <a-form-item label="一次报价确认时间" name="firstPriceConfirmTime">
        <a-input v-model:value="dataEditForm.firstPriceConfirmTime" placeholder="请输入一次报价确认时间"/>
      </a-form-item>
      <a-form-item label="一次报价确认用户" name="firstPriceConfirmUser">
        <a-input v-model:value="dataEditForm.firstPriceConfirmUser" placeholder="请输入一次报价确认用户"/>
      </a-form-item>
      <a-form-item label="二次报价" require  name="secondPrice">
        <a-input v-model:value="dataEditForm.secondPrice" placeholder="请输入二次报价"/>
      </a-form-item>
      <a-form-item label="二次报价时间" require  name="secondPriceTime">
        <a-input v-model:value="dataEditForm.secondPriceTime" placeholder="请输入二次报价时间"/>
      </a-form-item>
      <a-form-item label="二次报价用户" require  name="secondPriceUser">
        <a-input v-model:value="dataEditForm.secondPriceUser" placeholder="请输入二次报价用户"/>
      </a-form-item>
      <a-form-item label="二次报价确认" name="secondPriceConfirm">
        <a-input v-model:value="dataEditForm.secondPriceConfirm" placeholder="请输入二次报价确认"/>
      </a-form-item>
      <a-form-item label="二次报价确认时间" name="secondPriceConfirmTime">
        <a-input v-model:value="dataEditForm.secondPriceConfirmTime" placeholder="请输入二次报价确认时间"/>
      </a-form-item>
      <a-form-item label="" name="secondPriceConfirmUser">
        <a-input v-model:value="dataEditForm.secondPriceConfirmUser" placeholder="请输入"/>
      </a-form-item>
      <a-form-item label="订单状态" require  name="status">
        <a-input v-model:value="dataEditForm.status" placeholder="请输入订单状态"/>
      </a-form-item>
      <a-form-item label="订金" require  name="deposit">
        <a-input v-model:value="dataEditForm.deposit" placeholder="请输入订金"/>
      </a-form-item>
      <a-form-item label="订金支付时间" require  name="depositTime">
        <a-input v-model:value="dataEditForm.depositTime" placeholder="请输入订金支付时间"/>
      </a-form-item>
      <a-form-item label="支付用户" require  name="depositUser">
        <a-input v-model:value="dataEditForm.depositUser" placeholder="请输入支付用户"/>
      </a-form-item>
      <a-form-item label="尾款" require  name="retainage">
        <a-input v-model:value="dataEditForm.retainage" placeholder="请输入尾款"/>
      </a-form-item>
      <a-form-item label="支付尾款时间" require  name="retainageTime">
        <a-input v-model:value="dataEditForm.retainageTime" placeholder="请输入支付尾款时间"/>
      </a-form-item>
      <a-form-item label="支付尾款用户" require  name="retainageUser">
        <a-input v-model:value="dataEditForm.retainageUser" placeholder="请输入支付尾款用户"/>
      </a-form-item>
      <a-form-item label="合同" require  name="contract">
        <a-input v-model:value="dataEditForm.contract" placeholder="请输入合同"/>
      </a-form-item>
      <a-form-item label="合同上传时间" require  name="contractTime">
        <a-input v-model:value="dataEditForm.contractTime" placeholder="请输入合同上传时间"/>
      </a-form-item>
      <a-form-item label="合同上传用户" require  name="contractUser">
        <a-input v-model:value="dataEditForm.contractUser" placeholder="请输入合同上传用户"/>
      </a-form-item>
      <a-form-item label="创建人" require  name="createUser">
        <a-input v-model:value="dataEditForm.createUser" placeholder="请输入创建人"/>
      </a-form-item>
      <a-form-item label="创建时间" require  name="createTime">
        <a-input v-model:value="dataEditForm.createTime" placeholder="请输入创建时间"/>
      </a-form-item>
    </a-form>
  </c-simple-dialog>

  <!-- 详情 -->
  <c-simple-dialog
    ref="dialogDetailRef"
    mode="outer"
    title="详情"
    subUrl="/base/tOrder/saveTOrder"
    width="66%"
    @ok="doSearch"
    @check="doDetailCheck"
  >
    <a-form :wrapper-col="horizontal.wrapperCol" :label-col="horizontal.labelCol" ref="formDetailRef" :model="dataDetailForm" :rules="formDetailRules">
      <a-form-item label="订单名称" require  name="name">
        <a-input v-model:value="dataDetailForm.name" readOnly placeholder="请输入订单名称"/>
      </a-form-item>
      <a-form-item label="购买产品" name="powerSite">
        <a-input v-model:value="dataDetailForm.powerSite" readOnly placeholder="请输入购买产品"/>
      </a-form-item>
      <a-form-item label="一次报价" require  name="firstPrice">
        <a-input v-model:value="dataDetailForm.firstPrice" readOnly placeholder="请输入一次报价"/>
      </a-form-item>
      <a-form-item label="一次报价时间" require  name="firstPriceTime">
        <a-input v-model:value="dataDetailForm.firstPriceTime" readOnly placeholder="请输入一次报价时间"/>
      </a-form-item>
      <a-form-item label="一次报价用户" require  name="firstPriceUser">
        <a-input v-model:value="dataDetailForm.firstPriceUser" readOnly placeholder="请输入一次报价用户"/>
      </a-form-item>
      <a-form-item label="一次报价确认" name="firstPriceConfirm">
        <a-input v-model:value="dataDetailForm.firstPriceConfirm" readOnly placeholder="请输入一次报价确认"/>
      </a-form-item>
      <a-form-item label="一次报价确认时间" name="firstPriceConfirmTime">
        <a-input v-model:value="dataDetailForm.firstPriceConfirmTime" readOnly placeholder="请输入一次报价确认时间"/>
      </a-form-item>
      <a-form-item label="一次报价确认用户" name="firstPriceConfirmUser">
        <a-input v-model:value="dataDetailForm.firstPriceConfirmUser" readOnly placeholder="请输入一次报价确认用户"/>
      </a-form-item>
      <a-form-item label="二次报价" require  name="secondPrice">
        <a-input v-model:value="dataDetailForm.secondPrice" readOnly placeholder="请输入二次报价"/>
      </a-form-item>
      <a-form-item label="二次报价时间" require  name="secondPriceTime">
        <a-input v-model:value="dataDetailForm.secondPriceTime" readOnly placeholder="请输入二次报价时间"/>
      </a-form-item>
      <a-form-item label="二次报价用户" require  name="secondPriceUser">
        <a-input v-model:value="dataDetailForm.secondPriceUser" readOnly placeholder="请输入二次报价用户"/>
      </a-form-item>
      <a-form-item label="二次报价确认" name="secondPriceConfirm">
        <a-input v-model:value="dataDetailForm.secondPriceConfirm" readOnly placeholder="请输入二次报价确认"/>
      </a-form-item>
      <a-form-item label="二次报价确认时间" name="secondPriceConfirmTime">
        <a-input v-model:value="dataDetailForm.secondPriceConfirmTime" readOnly placeholder="请输入二次报价确认时间"/>
      </a-form-item>
      <a-form-item label="" name="secondPriceConfirmUser">
        <a-input v-model:value="dataDetailForm.secondPriceConfirmUser" readOnly placeholder="请输入"/>
      </a-form-item>
      <a-form-item label="订单状态" require  name="status">
        <a-input v-model:value="dataDetailForm.status" readOnly placeholder="请输入订单状态"/>
      </a-form-item>
      <a-form-item label="订金" require  name="deposit">
        <a-input v-model:value="dataDetailForm.deposit" readOnly placeholder="请输入订金"/>
      </a-form-item>
      <a-form-item label="订金支付时间" require  name="depositTime">
        <a-input v-model:value="dataDetailForm.depositTime" readOnly placeholder="请输入订金支付时间"/>
      </a-form-item>
      <a-form-item label="支付用户" require  name="depositUser">
        <a-input v-model:value="dataDetailForm.depositUser" readOnly placeholder="请输入支付用户"/>
      </a-form-item>
      <a-form-item label="尾款" require  name="retainage">
        <a-input v-model:value="dataDetailForm.retainage" readOnly placeholder="请输入尾款"/>
      </a-form-item>
      <a-form-item label="支付尾款时间" require  name="retainageTime">
        <a-input v-model:value="dataDetailForm.retainageTime" readOnly placeholder="请输入支付尾款时间"/>
      </a-form-item>
      <a-form-item label="支付尾款用户" require  name="retainageUser">
        <a-input v-model:value="dataDetailForm.retainageUser" readOnly placeholder="请输入支付尾款用户"/>
      </a-form-item>
      <a-form-item label="合同" require  name="contract">
        <a-input v-model:value="dataDetailForm.contract" readOnly placeholder="请输入合同"/>
      </a-form-item>
      <a-form-item label="合同上传时间" require  name="contractTime">
        <a-input v-model:value="dataDetailForm.contractTime" readOnly placeholder="请输入合同上传时间"/>
      </a-form-item>
      <a-form-item label="合同上传用户" require  name="contractUser">
        <a-input v-model:value="dataDetailForm.contractUser" readOnly placeholder="请输入合同上传用户"/>
      </a-form-item>
      <a-form-item label="创建人" require  name="createUser">
        <a-input v-model:value="dataDetailForm.createUser" readOnly placeholder="请输入创建人"/>
      </a-form-item>
      <a-form-item label="创建时间" require  name="createTime">
        <a-input v-model:value="dataDetailForm.createTime" readOnly placeholder="请输入创建时间"/>
      </a-form-item>
    </a-form>
  </c-simple-dialog>
  </div>
</template>

<script setup>
import { getCurrentInstance, ref } from 'vue'
import http from 'vue-antd-admin-npm/src/plugins/axios'
import { message } from 'ant-design-vue'

const { proxy } = getCurrentInstance()

const queryParam = ref({
  name: '',
  status: ''
})
const horizontal = ref({ labelCol: { span: 6 }, wrapperCol: { span: 16 } })
const tableColumns = ref([
  { title: '操作', dataIndex: 'actions', width: 200, scopedSlots: { customRender: 'actions' } },
  { title: '订单名称', dataIndex: 'name', align: 'center', sorter: false },
  { title: '购买产品', dataIndex: 'powerSite', align: 'center', sorter: false },
  { title: '一次报价', dataIndex: 'firstPrice', align: 'center', sorter: false },
  { title: '一次报价时间', dataIndex: 'firstPriceTime', align: 'center', sorter: false },
  { title: '一次报价用户', dataIndex: 'firstPriceUser', align: 'center', sorter: false },
  { title: '一次报价确认', dataIndex: 'firstPriceConfirm', align: 'center', sorter: false },
  { title: '一次报价确认时间', dataIndex: 'firstPriceConfirmTime', align: 'center', sorter: false },
  { title: '一次报价确认用户', dataIndex: 'firstPriceConfirmUser', align: 'center', sorter: false },
  { title: '二次报价', dataIndex: 'secondPrice', align: 'center', sorter: false },
  { title: '二次报价时间', dataIndex: 'secondPriceTime', align: 'center', sorter: false },
  { title: '二次报价用户', dataIndex: 'secondPriceUser', align: 'center', sorter: false },
  { title: '二次报价确认', dataIndex: 'secondPriceConfirm', align: 'center', sorter: false },
  { title: '二次报价确认时间', dataIndex: 'secondPriceConfirmTime', align: 'center', sorter: false },
  { title: '', dataIndex: 'secondPriceConfirmUser', align: 'center', sorter: false },
  { title: '订单状态', dataIndex: 'status', align: 'center', sorter: false },
  { title: '订金', dataIndex: 'deposit', align: 'center', sorter: false },
  { title: '订金支付时间', dataIndex: 'depositTime', align: 'center', sorter: false },
  { title: '支付用户', dataIndex: 'depositUser', align: 'center', sorter: false },
  { title: '尾款', dataIndex: 'retainage', align: 'center', sorter: false },
  { title: '支付尾款时间', dataIndex: 'retainageTime', align: 'center', sorter: false },
  { title: '支付尾款用户', dataIndex: 'retainageUser', align: 'center', sorter: false },
  { title: '合同', dataIndex: 'contract', align: 'center', sorter: false },
  { title: '合同上传时间', dataIndex: 'contractTime', align: 'center', sorter: false },
  { title: '合同上传用户', dataIndex: 'contractUser', align: 'center', sorter: false },
  { title: '创建人', dataIndex: 'createUser', align: 'center', sorter: false },
  { title: '创建时间', dataIndex: 'createTime', align: 'center', sorter: false }
])
const tablePage = ref()
function doSearch () {
  tablePage.value.doSearch()
}
const dialogAddRef = ref()
const formAddRef = ref()

const formAddRules = {
  name: [{ required: true, message: '请输入订单名称!!' }],
  powerSite: [{ required: false, message: '请输入购买产品!!' }],
  firstPrice: [{ required: true, message: '请输入一次报价!!' }],
  firstPriceTime: [{ required: true, message: '请输入一次报价时间!!' }],
  firstPriceUser: [{ required: true, message: '请输入一次报价用户!!' }],
  firstPriceConfirm: [{ required: false, message: '请输入一次报价确认!!' }],
  firstPriceConfirmTime: [{ required: false, message: '请输入一次报价确认时间!!' }],
  firstPriceConfirmUser: [{ required: false, message: '请输入一次报价确认用户!!' }],
  secondPrice: [{ required: true, message: '请输入二次报价!!' }],
  secondPriceTime: [{ required: true, message: '请输入二次报价时间!!' }],
  secondPriceUser: [{ required: true, message: '请输入二次报价用户!!' }],
  secondPriceConfirm: [{ required: false, message: '请输入二次报价确认!!' }],
  secondPriceConfirmTime: [{ required: false, message: '请输入二次报价确认时间!!' }],
  secondPriceConfirmUser: [{ required: false, message: '请输入!!' }],
  status: [{ required: true, message: '请输入订单状态!!' }],
  deposit: [{ required: true, message: '请输入订金!!' }],
  depositTime: [{ required: true, message: '请输入订金支付时间!!' }],
  depositUser: [{ required: true, message: '请输入支付用户!!' }],
  retainage: [{ required: true, message: '请输入尾款!!' }],
  retainageTime: [{ required: true, message: '请输入支付尾款时间!!' }],
  retainageUser: [{ required: true, message: '请输入支付尾款用户!!' }],
  contract: [{ required: true, message: '请输入合同!!' }],
  contractTime: [{ required: true, message: '请输入合同上传时间!!' }],
  contractUser: [{ required: true, message: '请输入合同上传用户!!' }],
  createUser: [{ required: true, message: '请输入创建人!!' }],
  createTime: [{ required: true, message: '请输入创建时间!!' }]
}
const dataAddForm = ref({
  name: '',
  powerSite: '',
  firstPrice: '',
  firstPriceTime: '',
  firstPriceUser: '',
  firstPriceConfirm: '',
  firstPriceConfirmTime: '',
  firstPriceConfirmUser: '',
  secondPrice: '',
  secondPriceTime: '',
  secondPriceUser: '',
  secondPriceConfirm: '',
  secondPriceConfirmTime: '',
  secondPriceConfirmUser: '',
  status: '',
  deposit: '',
  depositTime: '',
  depositUser: '',
  retainage: '',
  retainageTime: '',
  retainageUser: '',
  contract: '',
  contractTime: '',
  contractUser: '',
  createUser: '',
  createTime: ''
})
function doAddCheck () {
  formAddRef.value.validate().then(() => {
    dialogAddRef.value.submit(dataAddForm.value)
  })
}
const dialogEditRef = ref()
const formEditRef = ref()

const formEditRules = {
  name: [{ required: true, message: '请输入订单名称!!' }],
  powerSite: [{ required: false, message: '请输入购买产品!!' }],
  firstPrice: [{ required: true, message: '请输入一次报价!!' }],
  firstPriceTime: [{ required: true, message: '请输入一次报价时间!!' }],
  firstPriceUser: [{ required: true, message: '请输入一次报价用户!!' }],
  firstPriceConfirm: [{ required: false, message: '请输入一次报价确认!!' }],
  firstPriceConfirmTime: [{ required: false, message: '请输入一次报价确认时间!!' }],
  firstPriceConfirmUser: [{ required: false, message: '请输入一次报价确认用户!!' }],
  secondPrice: [{ required: true, message: '请输入二次报价!!' }],
  secondPriceTime: [{ required: true, message: '请输入二次报价时间!!' }],
  secondPriceUser: [{ required: true, message: '请输入二次报价用户!!' }],
  secondPriceConfirm: [{ required: false, message: '请输入二次报价确认!!' }],
  secondPriceConfirmTime: [{ required: false, message: '请输入二次报价确认时间!!' }],
  secondPriceConfirmUser: [{ required: false, message: '请输入!!' }],
  status: [{ required: true, message: '请输入订单状态!!' }],
  deposit: [{ required: true, message: '请输入订金!!' }],
  depositTime: [{ required: true, message: '请输入订金支付时间!!' }],
  depositUser: [{ required: true, message: '请输入支付用户!!' }],
  retainage: [{ required: true, message: '请输入尾款!!' }],
  retainageTime: [{ required: true, message: '请输入支付尾款时间!!' }],
  retainageUser: [{ required: true, message: '请输入支付尾款用户!!' }],
  contract: [{ required: true, message: '请输入合同!!' }],
  contractTime: [{ required: true, message: '请输入合同上传时间!!' }],
  contractUser: [{ required: true, message: '请输入合同上传用户!!' }],
  createUser: [{ required: true, message: '请输入创建人!!' }],
  createTime: [{ required: true, message: '请输入创建时间!!' }]
}
const dataEditForm = ref({
  name: '',
  powerSite: '',
  firstPrice: '',
  firstPriceTime: '',
  firstPriceUser: '',
  firstPriceConfirm: '',
  firstPriceConfirmTime: '',
  firstPriceConfirmUser: '',
  secondPrice: '',
  secondPriceTime: '',
  secondPriceUser: '',
  secondPriceConfirm: '',
  secondPriceConfirmTime: '',
  secondPriceConfirmUser: '',
  status: '',
  deposit: '',
  depositTime: '',
  depositUser: '',
  retainage: '',
  retainageTime: '',
  retainageUser: '',
  contract: '',
  contractTime: '',
  contractUser: '',
  createUser: '',
  createTime: ''
})
function doEditCheck () {
  formEditRef.value.validate().then(() => {
    dialogEditRef.value.submit(dataEditForm.value)
  })
}
const dialogDetailRef = ref()
const formDetailRef = ref()

const formDetailRules = {
  name: [{ required: true, message: 'null!' }],
  powerSite: [{ required: false, message: 'null!' }],
  firstPrice: [{ required: true, message: 'null!' }],
  firstPriceTime: [{ required: true, message: 'null!' }],
  firstPriceUser: [{ required: true, message: 'null!' }],
  firstPriceConfirm: [{ required: false, message: 'null!' }],
  firstPriceConfirmTime: [{ required: false, message: 'null!' }],
  firstPriceConfirmUser: [{ required: false, message: 'null!' }],
  secondPrice: [{ required: true, message: 'null!' }],
  secondPriceTime: [{ required: true, message: 'null!' }],
  secondPriceUser: [{ required: true, message: 'null!' }],
  secondPriceConfirm: [{ required: false, message: 'null!' }],
  secondPriceConfirmTime: [{ required: false, message: 'null!' }],
  secondPriceConfirmUser: [{ required: false, message: 'null!' }],
  status: [{ required: true, message: 'null!' }],
  deposit: [{ required: true, message: 'null!' }],
  depositTime: [{ required: true, message: 'null!' }],
  depositUser: [{ required: true, message: 'null!' }],
  retainage: [{ required: true, message: 'null!' }],
  retainageTime: [{ required: true, message: 'null!' }],
  retainageUser: [{ required: true, message: 'null!' }],
  contract: [{ required: true, message: 'null!' }],
  contractTime: [{ required: true, message: 'null!' }],
  contractUser: [{ required: true, message: 'null!' }],
  createUser: [{ required: true, message: 'null!' }],
  createTime: [{ required: true, message: 'null!' }]
}
const dataDetailForm = ref({
  name: '',
  powerSite: '',
  firstPrice: '',
  firstPriceTime: '',
  firstPriceUser: '',
  firstPriceConfirm: '',
  firstPriceConfirmTime: '',
  firstPriceConfirmUser: '',
  secondPrice: '',
  secondPriceTime: '',
  secondPriceUser: '',
  secondPriceConfirm: '',
  secondPriceConfirmTime: '',
  secondPriceConfirmUser: '',
  status: '',
  deposit: '',
  depositTime: '',
  depositUser: '',
  retainage: '',
  retainageTime: '',
  retainageUser: '',
  contract: '',
  contractTime: '',
  contractUser: '',
  createUser: '',
  createTime: ''
})
function doDetailCheck () {
  formDetailRef.value.validate().then(() => {
    dialogDetailRef.value.submit(dataDetailForm.value)
  })
}
async function optionDropdownClick ({ type, record }) {
  if (type === 'add') {
    dataAddForm.value = {
      name: '',
      powerSite: '',
      firstPrice: '',
      firstPriceTime: '',
      firstPriceUser: '',
      firstPriceConfirm: '',
      firstPriceConfirmTime: '',
      firstPriceConfirmUser: '',
      secondPrice: '',
      secondPriceTime: '',
      secondPriceUser: '',
      secondPriceConfirm: '',
      secondPriceConfirmTime: '',
      secondPriceConfirmUser: '',
      status: '',
      deposit: '',
      depositTime: '',
      depositUser: '',
      retainage: '',
      retainageTime: '',
      retainageUser: '',
      contract: '',
      contractTime: '',
      contractUser: '',
      createUser: '',
      createTime: ''
    }
    dialogAddRef.value.show()
  }
  if (type === 'edit') {
    if (record) {
      await http
        .$get('/base/tOrder/findTOrderById', { id: record.id })
        .then(({ data }) => {
          Object.assign(dataEditForm.value, data)
        })
    }
    dialogEditRef.value.show()
  }
  if (type === 'detail') {
    if (record) {
      await http
        .$get('/base/tOrder/findTOrderById', { id: record.id })
        .then(({ data }) => {
          Object.assign(dataDetailForm.value, data)
        })
    }
    dialogDetailRef.value.show()
  }
  if (type === 'delete') {
    if (record) {
      await http
        .$delete(`/base/tOrder/deleteTOrderById?id=${record.id}`)
        .then(({ msg }) => {
          message.success(msg, 0.2).then(() => {
            doSearch()
          })
        })
    }
  }
}
</script>
<style lang="less" scoped>
    .mlr {
        margin: 0 2px
    }
    /deep/ .cred {
        color: #ff4d4f;
    }
    .reset-pw {
        margin-left: calc(1 /6 * 100%);
        color: #1890ff;
    }
</style>
