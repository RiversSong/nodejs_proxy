package com.boating.plantExchange.base.controller;

import com.boating.framework.springboot.common.dal.dto.Pager;
import com.boating.framework.springboot.web.ApiResponse;
import com.boating.plantExchange.base.dto.TOrderDTO;
import com.boating.plantExchange.base.service.TOrderService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

/**
 * 订单表
 *
 * @author kernespring
 * @email kernespring@163.com
 * @date Fri Jan 09 11:09:16 CST 2026
 */
@Api("订单表")
@Validated
@RestController
@RequestMapping("base/tOrder")
public class TOrderController {
    /**
     * 服务对象
     */
    @Autowired
    private TOrderService tOrderService;

    /**
     * 分页获取列表
     * @param tOrderDTO
     * @return 列表记录
     */
    @ApiImplicitParams(value = { @ApiImplicitParam(name = "firstResult", value = "查询记录起始行", dataType = "Integer", paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "每页显示记录数", dataType = "Integer", paramType = "query"), })
    @ApiOperation("分页查询订单表")
    @PostMapping("/page")
    public ApiResponse<Pager<TOrderDTO>> findTOrderPager(TOrderDTO tOrderDTO) {
        return ApiResponse.getSuccResponse(tOrderService.findTOrderPager(tOrderDTO));
    }

    /**
     * 根据主键id查询记录
     * @param id
     * @return 单体记录
     */
    @ApiOperation("根据主键id查询记录")
    @GetMapping("/findTOrderById")
    public ApiResponse<TOrderDTO> findTOrderById(@ApiParam("id") @RequestParam(value = "id") Long id) {
        return ApiResponse.getSuccResponse("查询成功！", tOrderService.findTOrderById(id));
    }

    /**
     * 新增数据
     * @param tOrderDTO
     * @return
     */
    @ApiOperation("保存")
    @PostMapping("/saveTOrder")
    public ApiResponse<TOrderDTO> saveTOrder(@RequestBody @Valid TOrderDTO tOrderDTO) {
        return ApiResponse.getSuccResponse("保存成功！", tOrderService.saveTOrder(tOrderDTO));
    }

    /**
     * 根据主键id删除记录
     * @param id
     * @return
     */
    @ApiOperation("根据主键id删除记录")
    @DeleteMapping("/deleteTOrderById")
    public ApiResponse<TOrderDTO> deleteTOrderByid(@ApiParam("id") @RequestParam(value = "id") Long id) {
        return ApiResponse.getSuccResponse("删除成功！", tOrderService.deleteTOrderById(id));
    }
}
