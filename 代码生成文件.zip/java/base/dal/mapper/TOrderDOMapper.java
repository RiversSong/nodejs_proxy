package com.boating.plantExchange.base.dal.mapper;

import com.boating.plantExchange.base.dto.TOrderDTO;
import com.boating.plantExchange.base.dal.model.TOrderDO;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.additional.insert.InsertListMapper;

/**
 * 订单表
 *
 * @author kernespring
 * @email kernespring@163.com
 * @date Fri Jan 09 11:09:16 CST 2026
 */
@Repository
public interface TOrderDOMapper extends Mapper<TOrderDO>, InsertListMapper<TOrderDO> {
}
