package com.boating.plantExchange.base.dal.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.Date;
import java.io.Serializable;

/**
 * 订单表
 *
 * @author kernespring
 * @email kernespring@163.com
 * @date Fri Jan 09 11:09:16 CST 2026
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@Table(name = "t_order")
public class TOrderDO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@Id
	private Long id;
	/**
	 * 订单名称
	 */
	private String name;
	/**
	 * 购买产品
	 */
	private String powerSite;
	/**
	 * 一次报价
	 */
	private String firstPrice;
	/**
	 * 一次报价时间
	 */
	private Date firstPriceTime;
	/**
	 * 一次报价用户
	 */
	private String firstPriceUser;
	/**
	 * 一次报价确认
	 */
	private String firstPriceConfirm;
	/**
	 * 一次报价确认时间
	 */
	private Date firstPriceConfirmTime;
	/**
	 * 一次报价确认用户
	 */
	private String firstPriceConfirmUser;
	/**
	 * 二次报价
	 */
	private String secondPrice;
	/**
	 * 二次报价时间
	 */
	private Date secondPriceTime;
	/**
	 * 二次报价用户
	 */
	private String secondPriceUser;
	/**
	 * 二次报价确认
	 */
	private String secondPriceConfirm;
	/**
	 * 二次报价确认时间
	 */
	private Date secondPriceConfirmTime;
	/**
	 * 
	 */
	private String secondPriceConfirmUser;
	/**
	 * 订单状态
	 */
	private String status;
	/**
	 * 订金
	 */
	private String deposit;
	/**
	 * 订金支付时间
	 */
	private Date depositTime;
	/**
	 * 支付用户
	 */
	private String depositUser;
	/**
	 * 尾款
	 */
	private String retainage;
	/**
	 * 支付尾款时间
	 */
	private Date retainageTime;
	/**
	 * 支付尾款用户
	 */
	private String retainageUser;
	/**
	 * 合同
	 */
	private String contract;
	/**
	 * 合同上传时间
	 */
	private Date contractTime;
	/**
	 * 合同上传用户
	 */
	private String contractUser;
	/**
	 * 创建人
	 */
	private String createUser;
	/**
	 * 创建时间
	 */
	private Date createTime;

}
