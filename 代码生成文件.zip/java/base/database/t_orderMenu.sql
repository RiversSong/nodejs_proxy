-- 菜单SQL
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    VALUES ('','0', '订单表', 'base/tOrder', NULL, '1', 'config', '6', '12700055545', '2009462448486096896','F','base/tOrder',0,now(),'generator',now(),'generator');

-- 菜单对应按钮SQL
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '查看', null, 'base:tOrder:list', '2', null, '1', '12700055545', '2009462448486096897','F','base/tOrder',1,now(),'generator',now(),'generator';
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '新增', null, 'base:tOrder:save', '2', null, '2', '12700055545', '2009462448486096898','F','base/tOrder',1,now(),'generator',now(),'generator';
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '修改', null, 'base:tOrder:update', '2', null, '3', '12700055545', '2009462448486096899','F','base/tOrder',1,now(),'generator',now(),'generator';
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '详情', null, 'base:tOrder:detail', '2', null, '4', '12700055545', '2009462448486096900','F','base/tOrder',1,now(),'generator',now(),'generator';
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '删除', null, 'base:tOrder:delete', '2', null, '5', '12700055545', '2009462448486096901','F','base/tOrder',1,now(),'generator',now(),'generator';
INSERT INTO `sys_menu` (`route_name`,`parent_id`, `name`, `url`, `perms`, `type`, `icon`, `order_num`,app_id,menu_id,is_halt,component,is_leaf,create_datetime,create_user,modify_datetime,modify_user)
    SELECT '','2009462448486096896', '通用导出', null, 'base:tOrder:commonExport', '2', null, '6', '12700055545', '2009462448486096902','F','base/tOrder',1,now(),'generator',now(),'generator';

CREATE TABLE `t_order`  (
     PRIMARY KEY (`id`)
);
