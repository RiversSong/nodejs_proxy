package com.boating.plantExchange.base.dto;

import java.io.Serializable;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import com.boating.base.usercenter.common.annotation.Dict;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 订单表
 *
 * @author kernespring
 * @email kernespring@163.com
 * @date Fri Jan 09 11:09:16 CST 2026
 */
@Data
public class TOrderDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@ApiModelProperty(value = "id")
	private Long id;
	/**
	 * 订单名称
	 */
	@ApiModelProperty(value = "订单名称")
	private String name;
	/**
	 * 购买产品
	 */
	@ApiModelProperty(value = "购买产品")
	private String powerSite;
	/**
	 * 一次报价
	 */
	@ApiModelProperty(value = "一次报价")
	private String firstPrice;
	/**
	 * 一次报价时间
	 */
	@ApiModelProperty(value = "一次报价时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date firstPriceTime;
	/**
	 * 一次报价用户
	 */
	@ApiModelProperty(value = "一次报价用户")
	private String firstPriceUser;
	/**
	 * 一次报价确认
	 */
	@ApiModelProperty(value = "一次报价确认")
	private String firstPriceConfirm;
	/**
	 * 一次报价确认时间
	 */
	@ApiModelProperty(value = "一次报价确认时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date firstPriceConfirmTime;
	/**
	 * 一次报价确认用户
	 */
	@ApiModelProperty(value = "一次报价确认用户")
	private String firstPriceConfirmUser;
	/**
	 * 二次报价
	 */
	@ApiModelProperty(value = "二次报价")
	private String secondPrice;
	/**
	 * 二次报价时间
	 */
	@ApiModelProperty(value = "二次报价时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date secondPriceTime;
	/**
	 * 二次报价用户
	 */
	@ApiModelProperty(value = "二次报价用户")
	private String secondPriceUser;
	/**
	 * 二次报价确认
	 */
	@ApiModelProperty(value = "二次报价确认")
	private String secondPriceConfirm;
	/**
	 * 二次报价确认时间
	 */
	@ApiModelProperty(value = "二次报价确认时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date secondPriceConfirmTime;
	/**
	 * 
	 */
	@ApiModelProperty(value = "")
	private String secondPriceConfirmUser;
	/**
	 * 订单状态
	 */
	@ApiModelProperty(value = "订单状态")
	private String status;
	/**
	 * 订金
	 */
	@ApiModelProperty(value = "订金")
	private String deposit;
	/**
	 * 订金支付时间
	 */
	@ApiModelProperty(value = "订金支付时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date depositTime;
	/**
	 * 支付用户
	 */
	@ApiModelProperty(value = "支付用户")
	private String depositUser;
	/**
	 * 尾款
	 */
	@ApiModelProperty(value = "尾款")
	private String retainage;
	/**
	 * 支付尾款时间
	 */
	@ApiModelProperty(value = "支付尾款时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date retainageTime;
	/**
	 * 支付尾款用户
	 */
	@ApiModelProperty(value = "支付尾款用户")
	private String retainageUser;
	/**
	 * 合同
	 */
	@ApiModelProperty(value = "合同")
	private String contract;
	/**
	 * 合同上传时间
	 */
	@ApiModelProperty(value = "合同上传时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date contractTime;
	/**
	 * 合同上传用户
	 */
	@ApiModelProperty(value = "合同上传用户")
	private String contractUser;
	/**
	 * 创建人
	 */
	@ApiModelProperty(value = "创建人")
	private String createUser;
	/**
	 * 创建时间
	 */
	@ApiModelProperty(value = "创建时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

}
