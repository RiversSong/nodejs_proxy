package com.boating.plantExchange.base.service;

import com.boating.framework.springboot.common.dal.dto.Pager;
import com.boating.plantExchange.base.dto.TOrderDTO;
import com.boating.plantExchange.base.dal.model.TOrderDO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * 订单表
 *
 * @author kernespring
 * @email kernespring@163.com
 * @date Fri Jan 09 11:09:16 CST 2026
 */
public interface TOrderService {

    /**
     * 获取（分页）
     * @param tOrderDTO
     * @return
     */
    Pager<TOrderDTO> findTOrderPager(TOrderDTO tOrderDTO);

    /**
     * 根据主键获取数据
     * @param id 主键
     * @return
     */
    TOrderDTO findTOrderById(Long id);

    /**
     * 新增数据
     * @param tOrderDTO 实例对象
     * @return 实例对象
     */
    int saveTOrder(TOrderDTO tOrderDTO);

    /**
     * 通过主键id删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    int deleteTOrderById(Long id);

}

