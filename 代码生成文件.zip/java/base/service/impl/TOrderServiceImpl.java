package com.boating.plantExchange.base.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.boating.framework.springboot.common.sequence.wrapper.IdGeneratorWrapper;
import com.boating.framework.springboot.common.dal.dto.Pager;
import com.boating.framework.springboot.common.dal.helper.PagerHelper;
import com.boating.framework.springboot.common.exception.ServiceException;
import com.boating.framework.springboot.web.filter.SystemContext;
import com.boating.plantExchange.base.dal.mapper.TOrderDOMapper;
import com.boating.plantExchange.base.dal.model.TOrderDO;
import com.boating.plantExchange.base.dto.TOrderDTO;
import com.boating.plantExchange.base.service.TOrderService;
import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import tk.mybatis.mapper.entity.Example;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service("tOrderService")
public class TOrderServiceImpl implements TOrderService {
    @Autowired
    private TOrderDOMapper tOrderDOMapper;

    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private IdGeneratorWrapper idGenerator;

    @Override
    public Pager<TOrderDTO> findTOrderPager(TOrderDTO tOrderDTO) {
        PageHelper.offsetPage(SystemContext.getFirstResult(), SystemContext.getPageSize());

        Example example = new Example(TOrderDO.class);
        Example.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(tOrderDTO.getName())) {
            criteria.andEqualTo("name", tOrderDTO.getName());
        }
        if (StringUtils.isNotEmpty(tOrderDTO.getStatus())) {
            criteria.andEqualTo("status", tOrderDTO.getStatus());
        }
        // 排序
        if (StringUtils.isNotBlank(SystemContext.getSort())) {
            SystemContext.setSort(SystemContext.getSort().replaceAll("Desc",""));
            example.setOrderByClause(SystemContext.getSort());
        }
        List<TOrderDO> tOrderDOS = tOrderDOMapper.selectByExample(example);
        List<TOrderDTO> tOrderDTOS = modelMapper.map(tOrderDOS, new TypeToken<List<TOrderDTO>>(){}.getType());

        PageInfo<TOrderDO> pageInfo = new PageInfo<>(tOrderDOS);
        return PagerHelper.of(tOrderDTOS, pageInfo.getTotal());
    }

    @Override
    public TOrderDTO findTOrderById(Long id) {
        TOrderDO tOrderDO = tOrderDOMapper.selectByPrimaryKey(id);
        if (tOrderDO == null) {
            throw new ServiceException(30001, "数据信息不存在！id:" + id);
        }
        return modelMapper.map(tOrderDO, TOrderDTO.class);
    }

    @Override
    public int saveTOrder(TOrderDTO tOrderDTO) {
        // 编号唯一性校验
        // checkCodeUnique(tOrderDTO.getCode(), tOrderDTO.getId());

        TOrderDO tOrderDO = modelMapper.map(tOrderDTO, TOrderDO.class);
        if(tOrderDO.getId() != null) {
            TOrderDO existTOrder = tOrderDOMapper.selectByPrimaryKey(tOrderDTO.getId());
            if (existTOrder  == null) {
                throw new ServiceException(30001, "数据信息不存在！");
            }
            return tOrderDOMapper.updateByPrimaryKeySelective(tOrderDO);
        }
        tOrderDO.setId(idGenerator.nextLongId());
        tOrderDO.setCreateUser(SystemContext.getOperatorNameFromToken());
        tOrderDO.setCreateDatetime(new Date());
        return tOrderDOMapper.insertSelective(tOrderDO);
    }

    @Override
    public int deleteTOrderById(Long id) {
        TOrderDO existTOrder = tOrderDOMapper.selectByPrimaryKey(id);
        if (existTOrder  == null)
            throw new ServiceException(30001, "要删除的数据信息不存在！");
        return tOrderDOMapper.deleteByPrimaryKey(id);
    }
    public void checkCodeUnique(String code, Long id) {
        Example example = new Example(TOrderDO.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("code",code);
        if (id != null){
            criteria.andNotEqualTo("id",id);
        }
        if (tOrderDOMapper.selectCountByExample(example) > 0) {
            throw new ServiceException(30001, "编号重复了！");
        }
    }

}
